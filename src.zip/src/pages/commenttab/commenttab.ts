import { Component } from '@angular/core';
import { NavController, NavParams,Platform} from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import * as firebase from 'firebase';
import { AngularFireModule} from 'angularfire2';
import { AngularFireDatabaseModule, FirebaseListObservable, AngularFireDatabase} from 'angularfire2/database';

declare var window:any;
@Component({
  selector: 'page-commenttab',
  templateUrl: 'commenttab.html',
})
export class CommenttabPage {
commenttext:any;
statusid:any;
commentdata=[];
likes:any;
count:number;
db:any;counts:any;
commentstatus:Array <FirebaseListObservable<any>>;
afstatus:Array <FirebaseListObservable<any>>;
constructor(public platform:Platform,db: AngularFireDatabase,public http:Http,private storage: Storage,public navCtrl: NavController, public navParams: NavParams) {
    this.statusid= navParams.data;
    this.storage.set('statsid',navParams.data);
    this.db=db;
    this.likes='false';
    this.count=10;
    this.http.get("http://kanchan.mediaoncloud.com/briddgge/fetchStatusInner?post_id="+this.statusid).map(res => res.json()).subscribe(data => {
      this.commentdata=data.comment;
    })
    var refNew = this.db.list('/Count/'+this.statusid);
        refNew.subscribe((data)=>{
      
        this.afstatus=data;
   })

  var New = this.db.list('/Commentlikes/', { query: {
           orderByChild:'key'
        }}).map((array) => array.reverse()) as FirebaseListObservable<any[]>;
        New.subscribe((data)=>{
          var rawList=[];
          this.afstatus = [];    
          data.forEach(minispanshot =>{ 
          var refVal = minispanshot.$key;
          var refNew = this.db.list('/Count/'+refVal);
           refNew.subscribe((dataInner)=>{ 
             let newData = dataInner[0];
              rawList[refVal] = newData;
              this.commentstatus = rawList;
              console.log(this.commentstatus)
           })
         })
        })
}
send(afcount,afkey){

  this.storage.get('usrid').then((usrid)=>{
        this.http.get("http://kanchan.mediaoncloud.com/briddgge/saveComment?user_id="+usrid+"&post_id="+this.statusid+"&comment="+this.commenttext).map(res => res.json()).subscribe(data => {
            if(data.status=='Success'){
            var newcommentcount=JSON.parse(afcount)+1;
                var ref=this.db.list('/Count/'+ this.statusid);
                ref.update(afkey,{
                Commentcount:newcommentcount
            })
            var commentid=data.id;
            this.counts = this.db.list('/Commentlikes/'+commentid); 
            this.counts.push({ 
                Likes:0,
                likedislikevar:0,
            });
                this.platform.ready().then(() => {
                    window.plugins.toast.show("Comments posted", "short", "center");
                })
                this.commenttext='';
                this.http.get("http://kanchan.mediaoncloud.com/briddgge/fetchStatusInner?post_id="+this.statusid).map(res => res.json()).subscribe(data => {
                     this.commentdata=data.comment;
                })
            }else{             
                this.platform.ready().then(() => {
                    window.plugins.toast.show("Write your comment in commentbox", "short", "center");
                })
            }
        }) 
  })
}
like(c){
  this.likes='true';
  this.count=c+1;
  
}
unlike(c){
  this.likes='false';
  this.count=c-1;

}
}
