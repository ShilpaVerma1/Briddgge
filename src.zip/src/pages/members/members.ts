import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';


@Component({
  selector: 'page-members',
  templateUrl: 'members.html',
})
export class MembersPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }


}
