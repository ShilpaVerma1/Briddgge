import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ImagessPage} from '../imagess/imagess';
import { BriddggeHomePage } from '../briddggehome/briddggehome';
import { VideossPage } from '../videoss/videoss';
import { Http } from '@angular/http';

@Component({
  selector: 'page-otherprofile',
  templateUrl: 'otherprofile.html',
})
export class OtherprofilePage {
  tab1Root = ImagessPage;
  tab2Root = VideossPage;
  tab3Root = VideossPage;
  uid:any;profiledata=[]
constructor(public http:Http,public navCtrl: NavController, public navParams: NavParams) {
  this.uid=this.navParams.get('otheruserid');
  this.http.get("http://kanchan.mediaoncloud.com/briddgge/getProfile?user_id="+this.uid).map(res => res.json()).subscribe(data => {
      this.profiledata=data;
  })
}

}
